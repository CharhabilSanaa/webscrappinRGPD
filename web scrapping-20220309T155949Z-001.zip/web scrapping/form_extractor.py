# -*- coding: utf-8 -*-
"""
Created on Mon Jan 17 10:33:22 2022

@author: charhabil sanaa
"""

from bs4 import BeautifulSoup
from requests_html import HTMLSession
from urllib.parse import urljoin
import pandas as pd



# initialize an HTTP session
session = HTMLSession()

#data to extract:
#list of data to extract :
mairies=[]
adresses=[] 
horaires=[] 
telephones=[] 
faxes=[] 
courriels=[] 
sites=[] 

#get all forms from the web page :
    
def get_all_forms(url):
    """Returns all form tags found on a web page's `url` """
    # GET request
    res = session.get(url)
    # for javascript driven website
    # res.html.render()
    soup = BeautifulSoup(res.html.html, "html.parser")
    return soup.find_all("form")


def get_form_details(form):
    """Returns the HTML details of a form,
    including action, method and list of form controls (inputs, etc)"""
    details = {}
    # get the form action (requested URL)
    action = form.attrs.get("action").lower()
    # get the form method (POST, GET, DELETE, etc)
    # if not specified, GET is the default in HTML
    method = form.attrs.get("method", "get").lower()
    # get all form inputs
    inputs = []
    for input_tag in form.find_all("input"):
        # get type of input form control
        input_type = input_tag.attrs.get("type", "text")
        # get name attribute
        input_name = input_tag.attrs.get("name")
        # get the default value of that input tag
        input_value =input_tag.attrs.get("value", "")
        # get the default value of placeholder
        input_placeholder =input_tag.attrs.get("placeholder")
        # add everything to that list
        inputs.append({"type": input_type, "name": input_name,"placeholder":input_placeholder, "value": input_value})
    # put everything to the resulting dictionary
    details["action"] = action
    details["method"] = method
    details["inputs"] = inputs
    return details

url = "https://www.annuaire-mairie.fr/"
# get all form tags
forms = get_all_forms(url)
# iteratte over forms
for i, form in enumerate(forms, start=1):
    form_details = get_form_details(form)
    print("="*50, f"form #{i}", "="*50)
    print(form_details)
    
#Submitting Web Forms

first_form = get_all_forms(url)[0]
second_form = get_all_forms(url)[1]

# extract all form details
form_details = get_form_details(second_form)

#print("data of second form : ",second_form)

#the data we want to submit:
data = {}  #nom de la mairie
for input_tag in form_details["inputs"]:
    
    if input_tag["type"] == "hidden":
        # if it's hidden, use the default value
        data[input_tag["name"]] = input_tag["value"]
    elif input_tag["type"] == "text":
        # all others except submit, prompt the user to set it
        value = input(f"Enter the value of the field '{input_tag['name']}' (type: {input_tag['type']}): ")
        data[input_tag["name"]] = value #la valeur a inserer pour le champ
    
    
    """elif input_tag["type"] != "submit":
        # all others except submit, prompt the user to set it
        value = input(f"Enter the value of the field '{input_tag['name']}' (type: {input_tag['type']}): ")
        data[input_tag["name"]] = value #la valeur a inserer pour le champ"""
        

#print("data of second form : ",second_form)

# join the url with the action (form request URL)
url = urljoin(url, form_details["action"])

#print("methode : ",form_details["method"])
#print("data to search : ", data)

if form_details["method"] == "post":
    res = session.post(url, data=data)
elif form_details["method"] == "get":
    res = session.get(url, params=data)
    #print("res : ",res) => response 200 => status OK


#
# the below code is only for replacing relative URLs to absolute ones
soup = BeautifulSoup(res.content, "html.parser")


#print("soup content : ",soup)  #contenu de la nouvelle page web

for link in soup.find_all("link"):
    try:
        link.attrs["href"] = urljoin(url, link.attrs["href"])
    except:
        pass
for script in soup.find_all("script"):
    try:
        script.attrs["src"] = urljoin(url, script.attrs["src"])
    except:
        pass
for img in soup.find_all("img"):
    try:
        img.attrs["src"] = urljoin(url, img.attrs["src"])
    except:
        pass
for a in soup.find_all("a"):
    try:
        a.attrs["href"] = urljoin(url, a.attrs["href"])
    except:
        pass

# write the page content to a file
#newsoup = soup.replace('\u2013','')
#open("page.html", "w").write(str(soup))

#impression et la sauveagarde de la page web:

file = open("page.html", "w",encoding='utf-8') 
file.write(str(soup)) 




#extract data from soup

for b in soup.findAll('h3', attrs={'id':'mairie'}):
    mairies.append(b.text)
    
    
    
i=0

for a in soup.findAll('div', attrs={'class':'ville_info'}):
    
    #print (a)
    paragraphs=a.findAll("p", class_=False, id=False)
    #print ("paragraphes : " ,paragraphs)
    for paragraph in paragraphs:
        #print(" paragraph : ",paragraph)
        if i==0:
            adresses.append(paragraph.text.replace("Ã©", "é"))
        elif i==1:
            horaires.append(paragraph.text.replace("Ã©", "é"))
        elif i==3:
            telephones.append(paragraph.text.replace("Ã©", "é"))
        elif i==4:
            faxes.append(paragraph.text.replace("Ã©", "é"))
        elif i==5:
            courriels.append(paragraph.text.replace("Ã©", "é"))
        elif i==6:
            sites.append(paragraph.text.replace("Ã©", "é"))
        else :
            i=i+1
            continue
        i=i+1
        
    
    
     
#generate csv file and save data
    
df = pd.DataFrame({'Mairie':mairies,'Adresse':adresses , 'Horaire':horaires,
                   'Téléphone':telephones,'Faxes':faxes,'Courriel':courriels,'site':sites}) 
df.to_csv('source1.csv', index=False, encoding='utf-8')